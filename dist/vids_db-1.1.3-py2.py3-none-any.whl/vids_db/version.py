"""Simply contains the version of the app."""
VERSION = "1.1.3"
